import matplotlib.pyplot as plt
import numpy as np

# 数据
data = {
    5: 10.8182,
    6: 7.7273,
    7: 10.5455,
    8: 8.4091,
    9: 8.3182,
    10: 9.0000,
    11: 8.4091,
    12: 11.7273,
    13: 12.9545,
    14: 13.6364,
    15: 18.5000,
    16: 17.5455,
    17: 14.5909,
    18: 20.0000,
    19: 16.4545,
    20: 17.0455,
    21: 15.9545,
    22: 22.4091,
    23: 21.5000,
    24: 20.3182,
    25: 22.2727,
    26: 26.2727,
    27: 27.1818,
    28: 27.8182,
    29: 27.1818,
    30: 24.5000,
    31: 27.8636,
    32: 27.4545,
    33: 27.1364,
    34: 28.8636,
    35: 26.2727,
    36: 29.0455,
    37: 34.0455,
    38: 29.8636,
    39: 27.8636,
    40: 35.2727,
    41: 31.3636,
    42: 33.8182,
    43: 30.8182,
    44: 31.8636,
    45: 36.9091,
    46: 35.9545,
    47: 36.5909,
    48: 35.8182,
    49: 37.5909,
    50: 35.5000,
}

# 提取x和y值
x = list(data.keys())
y = list(data.values())

# 找到最高点和最低点
min_value = min(y)
max_value = max(y)
min_index = y.index(min_value)
max_index = y.index(max_value)
min_x = x[min_index]
max_x = x[max_index]

# 创建图形
plt.figure(figsize=(14, 7))

# 绘制折线图
plt.plot(
    x,
    y,
    "o-",
    color="#1f77b4",
    linewidth=2,
    markersize=8,
    markerfacecolor="white",
    markeredgewidth=2,
    markeredgecolor="#1f77b4",
)

# 标记最低点（最佳性能）
plt.scatter(
    min_x,
    min_value,
    s=150,
    color="green",
    zorder=5,
    label=f"Best Performance (H={min_x}, Rank={min_value:.1f})",
)

# 标记最高点（最差性能）
plt.scatter(
    max_x,
    max_value,
    s=150,
    color="red",
    zorder=5,
    label=f"Worst Performance (H={max_x}, Rank={max_value:.1f})",
)

# 添加标题和标签
plt.title("Mean Rank of Algorithm Performance Across Different H Values", fontsize=16)
plt.xlabel("Parameter H", fontsize=14)
plt.ylabel("Mean Rank", fontsize=14)  # 修改纵轴名称

# 设置网格
plt.grid(True, linestyle="--", alpha=0.7)

# 设置坐标轴范围
plt.xlim(min(x) - 1, max(x) + 1)
plt.ylim(min(y) - 5, max(y) + 5)

# 高亮关键区域
plt.axvspan(5, 12, alpha=0.1, color="green", label="Stable Region")
# plt.axvspan(7, 13, alpha=0.1, color="green", label="Low Sensitivity")
plt.axvspan(12, 50, alpha=0.1, color="red", label="Continuously Reteriorating Region")

# 添加图例
plt.legend(fontsize=12, loc="upper left")

# # 添加数据标签（只标记关键点）
# for xi, yi in zip(x, y):
#     if xi in [min_x, max_x, 5, 10, 20, 30, 40, 50]:
#         plt.annotate(
#             f"{yi:.1f}",
#             (xi, yi),
#             xytext=(0, 10),
#             textcoords="offset points",
#             ha="center",
#             fontsize=9,
#             weight="bold",
#         )

# 添加水平参考线
plt.axhline(y=min_value, color="green", linestyle="--", alpha=0.3)
plt.axhline(y=max_value, color="red", linestyle="--", alpha=0.3)

# 添加说明文本
plt.text(
    20,
    max_value + 1,
    f"Worst Performance: H={max_x}, Rank={max_value:.1f}",
    fontsize=20,
    color="red",
)
plt.text(
    20,
    min_value - 2,
    f"Best Performance: H={min_x}, Rank={min_value:.1f}",
    fontsize=20,
    color="green",
)

# 调整布局
plt.tight_layout()

# 保存和显示
plt.savefig("performance_vs_parameter.png", dpi=300)
plt.show()

# 输出关键点信息
print(f"最佳性能点: H={min_x}, Mean Rank={min_value:.4f}")
print(f"最差性能点: H={max_x}, Mean Rank={max_value:.4f}")
