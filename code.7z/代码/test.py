import numpy as np
from scipy.stats import rankdata

fitness_list = np.array(
    [
        np.load(f"testData\\parameter_analyze\\CQPSO_base_{i}.npz")["fitness"]
        for i in range(5, 51)
    ]
)
fitness_max_median_min_list = []
for i in range(46):
    a = []
    a.append(np.max(fitness_list[i, :, :], axis=0))
    a.append(np.median(fitness_list[i, :, :], axis=0))
    a.append(np.min(fitness_list[i, :, :], axis=0))
    fitness_max_median_min_list.append(a)

fitness_max_median_min_numpy = np.transpose(
    np.array(fitness_max_median_min_list), (2, 1, 0)
)
data = []
for i in range(fitness_max_median_min_numpy.shape[0]):
    sum_rank = np.zeros(fitness_max_median_min_numpy.shape[-1])
    for j in range(fitness_max_median_min_numpy.shape[1]):
        sum_rank += rankdata(fitness_max_median_min_numpy[i, j])
    data.append(rankdata(sum_rank))
