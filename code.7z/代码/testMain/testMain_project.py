import sys

sys.path.insert(0, sys.path[0] + "/../")
from EA_toolbox import *
import numpy as np
from QPSO_algorithms import *
import time
import multiprocessing

project_function_names = [
    spring_design,
    three_bar_truss,
    cantilever_beam_design,
    welded_beam_design,
    gear_train_design,
    pressure_vessel_optimization,
    speed_reducer_optimization,
    I_beam_vertical_deflection_design,
    tubular_column_design,
]


def get_parameter(func, algorithm_name):
    size = 200
    iter_num = 1000
    lb, ub, dim = get_lb_ub_dim(func)
    is_print = False
    init_function = random_init
    if algorithm_name == QPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 0.6)
    if algorithm_name == CQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num,
            lb,
            ub,
            is_print,
            10,
        )
    if algorithm_name == LQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num,
            lb,
            ub,
            is_print,
            1,
            0.5,
            0.001,
            0.1,
        )
    if algorithm_name == QDQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num // 2,
            lb,
            ub,
            is_print,
            0.6,
            0.001,
        )
    if algorithm_name == eQPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 1.5, 0.5)
    if algorithm_name == GQPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 1, 0.5)
    if algorithm_name == IGQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num,
            lb,
            ub,
            is_print,
            0.75,
            5,
            0.01,
        )
    if algorithm_name == QSPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 0.8, 0.4)
    if algorithm_name == GDQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num // 2,
            lb,
            ub,
            is_print,
            0.4,
            0.9,
            0.6,
            0.7,
        )
    if algorithm_name == IQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num,
            lb,
            ub,
            is_print,
            0.6,
            1,
            0.5,
            1e-3,
            0.1,
        )


def one_poccessing(result_list_diff_poccessing, algorithm_name, function_names):
    # 为当前进程设置唯一随机种子
    import random
    import numpy as np
    import time
    import os

    # 使用进程ID和时间戳创建唯一种子
    seed = int(time.time() * 1000) % 2**32 + os.getpid()
    random.seed(seed)
    np.random.seed(seed)

    result_in_one_poccessing = []
    for func in function_names:
        result_in_one_function = []
        algorithm = algorithm_name(*get_parameter(func, algorithm_name))
        result = algorithm.optimize()
        result_in_one_function.append(result[0].tolist())
        result_in_one_function.append(result[1])
        result_in_one_poccessing.append(result_in_one_function)
    result_list_diff_poccessing.append(result_in_one_poccessing)
    return result_in_one_poccessing


num_test = 100
algorithm_name = CQPSO

if __name__ == "__main__":
    start_time = time.time()
    print(
        "开始时间:",
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_time)),
    )

    manager = multiprocessing.Manager()
    result_list_diff_poccessing = manager.list()  # 使用 Manager 的共享列表

    num_test_bench_list = split_into_chunks(num_test, chunk_size=50)

    sum_count_test = 0
    for num_test_bench in num_test_bench_list:
        print(f"轮次:{sum_count_test+1}/{num_test}")
        sum_count_test += num_test_bench

        processes = []
        for _ in range(num_test_bench):
            p = multiprocessing.Process(
                target=one_poccessing,
                args=(
                    result_list_diff_poccessing,
                    algorithm_name,
                    project_function_names,
                ),
            )
            processes.append(p)
            p.start()
        for p in processes:
            p.join()

    fitness_list = []
    best_solution_list = [0 for _ in range(len(project_function_names))]
    best_fitness_list = [np.inf for _ in range(len(project_function_names))]
    for proccessing in range(num_test):
        fitness_list_in_one_proccessing = []
        for function in range(len(project_function_names)):
            fitness = result_list_diff_poccessing[proccessing][function][1]
            fitness_list_in_one_proccessing.append(fitness)
            if fitness < best_fitness_list[function]:
                best_fitness_list[function] = fitness
                best_solution_list[function] = result_list_diff_poccessing[proccessing][
                    function
                ][0]
        fitness_list.append(fitness_list_in_one_proccessing)

    # 将共享列表转换为普通列表
    results = list(fitness_list)

    # 转换为numpy数组
    # 结果数组形状为 (num_test, len(function_names))
    results_array = np.array(results)

    # 创建结果目录
    results_dir = "./testData"
    os.makedirs(results_dir, exist_ok=True)

    # 生成文件名
    algorithm_name_str = algorithm_name.__name__
    filename = f"{algorithm_name_str}_project.npy"
    filepath = os.path.join(results_dir, filename)

    # 保存为numpy文件
    np.save(filepath, results_array)
    print(f"结果已保存至: {filepath}")

    print(best_solution_list)
