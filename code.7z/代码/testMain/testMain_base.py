import sys

sys.path.insert(0, sys.path[0] + "/../")
from EA_toolbox import *
import numpy as np
from QPSO_algorithms import *
import time
import multiprocessing

function_names = [
    Sphere,
    Schwefel_226,
    Schwefel_222,
    Schwefel_12,
    Schwefel_221,
    Rosenbrock,
    Rastrigin,
    Ackley,
    Griewank,
    Penalized1,
    Penalized2,
]


def get_parameter(func, algorithm_name, dim=100):
    size = 200
    iter_num = 1000
    lb, ub, dim = get_lb_ub_dim(func, dim)
    is_print = False
    init_function = random_init
    if algorithm_name in [QPSO, QPSO_CM, QPSO_QO, CQPSO_SE]:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 0.6)
    if algorithm_name in [CQPSO, QPSO_SE, CQPSO_QO, CQPSO_CM]:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num,
            lb,
            ub,
            is_print,
            10,
        )
    if algorithm_name == LQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num,
            lb,
            ub,
            is_print,
            1,
            0.5,
            0.001,
            0.1,
        )
    if algorithm_name == QDQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num // 2,
            lb,
            ub,
            is_print,
            0.6,
            0.001,
        )
    if algorithm_name == eQPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 1.5, 0.5)
    if algorithm_name == GQPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 1, 0.5)
    if algorithm_name == IGQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num,
            lb,
            ub,
            is_print,
            0.75,
            5,
            0.01,
        )
    if algorithm_name == QSPSO:
        return (func, init_function, dim, size, iter_num, lb, ub, is_print, 0.8, 0.4)
    if algorithm_name == GDQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num // 2,
            lb,
            ub,
            is_print,
            0.4,
            0.9,
            0.6,
            0.7,
        )
    if algorithm_name == IQPSO:
        return (
            func,
            init_function,
            dim,
            size,
            iter_num,
            lb,
            ub,
            is_print,
            0.6,
            1,
            0.5,
            1e-3,
            0.1,
        )


def one_poccessing(result_list_diff_poccessing, algorithm_name, function_names):
    # 为当前进程设置唯一随机种子
    import random
    import numpy as np
    import time
    import os

    # 使用进程ID和时间戳创建唯一种子
    seed = int(time.time() * 1000) % 2**32 + os.getpid()
    random.seed(seed)
    np.random.seed(seed)

    result_in_one_poccessing = []
    for func in function_names:
        # 确保算法内部也使用这个种子
        algorithm = algorithm_name(*get_parameter(func, algorithm_name))
        algorithm_results = algorithm.optimize()
        result_in_one_poccessing.append((algorithm_results[1], algorithm_results[2]))

    result_list_diff_poccessing.append(result_in_one_poccessing)
    return result_in_one_poccessing


num_test = 100
algorithm_name = QPSO_CM

if __name__ == "__main__":
    start_time = time.time()
    print(
        "开始时间:",
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_time)),
    )

    manager = multiprocessing.Manager()
    result_list_diff_poccessing = manager.list()  # 使用 Manager 的共享列表

    num_test_bench_list = split_into_chunks(num_test, chunk_size=25)

    sum_count_test = 0
    for num_test_bench in num_test_bench_list:
        print(f"轮次:{sum_count_test+1}/{num_test}")
        sum_count_test += num_test_bench

        processes = []
        for _ in range(num_test_bench):
            p = multiprocessing.Process(
                target=one_poccessing,
                args=(result_list_diff_poccessing, algorithm_name, function_names),
            )
            processes.append(p)
            p.start()
        for p in processes:
            p.join()

    fitness_numpy = np.zeros((num_test, len(function_names)))
    fitness_history_list = []
    for j in range(len(function_names)):
        best_fitness = np.inf
        best_fitness_history = 0
        for i in range(num_test):
            fitness_numpy[i][j] = result_list_diff_poccessing[i][j][0]
            if fitness_numpy[i][j] < best_fitness:
                best_fitness = fitness_numpy[i][j]
                best_fitness_history = result_list_diff_poccessing[i][j][1]
        fitness_history_list.append(best_fitness_history.copy())

    # 转换为numpy数组
    fitness_history_numpy = np.array(fitness_history_list)

    # 创建结果目录
    results_dir = "./testData"
    os.makedirs(results_dir, exist_ok=True)

    # 生成文件名
    algorithm_name_str = algorithm_name.__name__
    filename = f"{algorithm_name_str}_base"
    filepath = os.path.join(results_dir, filename)

    # 保存为numpy文件
    np.savez(filepath, fitness=fitness_numpy, fitness_history=fitness_history_numpy)
    print(f"结果已保存至: {filepath}")
