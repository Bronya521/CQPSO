import zipfile
import datetime
import os
import matplotlib.pyplot as plt
import numpy as np
from testData.testData_base import *
from testData.testData_project import *
from testMain.testMain_base import get_parameter
from QPSO_algorithms import CQPSO
from EA_toolbox import *
from scipy.stats import friedmanchisquare, rankdata, wilcoxon
import scipy.stats as stats
from statsmodels.stats.multitest import multipletests
import seaborn as sns
import pandas as pd

function_names = [
    Sphere,
    Schwefel_226,
    Schwefel_222,
    Schwefel_12,
    Schwefel_221,
    Rosenbrock,
    Rastrigin,
    Ackley,
    Griewank,
    Penalized1,
    Penalized2,
]
project_function_names = [
    "spring_design",
    "three_bar_truss",
    "cantilever_beam_design",
    "welded_beam_design",
    "gear_train_design",
    "pressure_vessel_optimization",
    "speed_reducer_optimization",
    "I_beam_vertical_deflection_design",
    "corrugated_bulkhead_design",
    "tubular_column_design",
]

algorithm_names = [
    "QPSO",
    "CQPSO",
    "LQPSO",
    "QDQPSO",
    "eQPSO",
    "GQPSO",
    "IGQPSO",
    "QSPSO",
    "GDQPSO",
    "IQPSO",
]
ablation_experiment_algorithms = [
    "CQPSO",
    "CQPSO-CM",
    "CQPSO-QO",
    "QPSO+SE",
    "QPSO",
    "QPSO+QO",
    "QPSO+CM",
    "CQPSO-SE",
]
base_func_test_data = np.array(
    [
        np.load(f"./testData/{algorithm_name}_base.npz")["fitness"]
        for algorithm_name in algorithm_names
    ]
)


project_func_test_data = np.array(
    [
        project_func_data_QPSO,
        project_func_data_CQPSO,
        project_func_data_LQPSO,
        project_func_data_QDQPSO,
        project_func_data_eQPSO,
        project_func_data_GQPSO,
        project_func_data_IGQPSO,
        project_func_data_QSPSO,
        project_func_data_GDQPSO,
        project_func_data_IQPSO,
    ]
)


project_func_data_CQPSO_solution = [
    np.array(project_func_data_CQPSO_solution[i])
    for i in range(len(project_func_data_CQPSO_solution))
]


def base_median_best_worst_std(algorithm_names, base_func_test_data):
    for i in range(len(algorithm_names)):
        print(
            f"{algorithm_names[i]}: median:\n",
            np.median(base_func_test_data[i], axis=0),
        )
        print(f"{algorithm_names[i]}: best:\n", np.min(base_func_test_data[i], axis=0))
        print(f"{algorithm_names[i]}: worst:\n", np.max(base_func_test_data[i], axis=0))
        print(f"{algorithm_names[i]}: std:\n", np.std(base_func_test_data[i], axis=0))
        print("\n")


def project_median_best_worst_std():
    for i in range(len(algorithm_names)):
        data = project_func_test_data[i][:, np.array([0, 1, 2, 3, 4, 5, 6, 7, 9])]
        print(f"{algorithm_names[i]}: median:\n", np.median(data, axis=0))
        print(f"{algorithm_names[i]}: best:\n", np.min(data, axis=0))
        print(f"{algorithm_names[i]}: worst:\n", np.max(data, axis=0))
        print(f"{algorithm_names[i]}: std:\n", np.std(data, axis=0))
        print("\n")


# 定义绘制箱线图的函数
def plot_boxplot(data, title, x_labels, y_labels, save_path):
    # 创建箱体并设置样式
    fig, ax = plt.subplots()  # 创建一个图形及子图
    boxprops = dict(color="blue")  # 定义箱子的样式：边框颜色为蓝色，无填充
    medianprops = dict(
        color="red", linewidth=1
    )  # 定义中位数线的样式：颜色为红色，线宽为1
    whiskerprops = dict(
        color="black", linewidth=1.5, linestyle="--"
    )  # 定义须的样式：颜色为绿色，线宽为1.5，虚线
    flierprops = dict(
        marker="+", markerfacecolor="red", markeredgecolor="red", markersize=8
    )  # 定义异常值的样式

    # 绘制箱型图
    ax.boxplot(
        data,
        vert=True,
        patch_artist=False,  # 移除填充
        boxprops=boxprops,
        medianprops=medianprops,
        whiskerprops=whiskerprops,
        flierprops=flierprops,
    )

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]  # 设置全局字体为微软雅黑

    # 添加标签
    ax.set_title(title, fontsize=16)  # 设置标题及字体大小
    ax.set_ylabel(y_labels, fontsize=12)  # 设置 Y 轴标签及字体大小
    ax.set_xticklabels(
        x_labels, rotation=45, fontsize=10
    )  # 更改 X 轴标签，并旋转 45 度
    ax.grid(
        True, linestyle="-", linewidth=0.5, alpha=0.5
    )  # 显示网格线，样式为实线，线宽为0.5，透明度为0.5
    ax.set_yscale("log")
    # 保存图像
    # 将标题转换为文件名
    os.makedirs(save_path, exist_ok=True)
    filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
    plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")

    # 显示图形并继续执行代码
    plt.show(block=False)

    # 设置计时器在5秒后关闭窗口
    plt.pause(5)
    plt.close()


def plot_all_track_map(F=None):
    def plot_track_map(func, all_points, track, lb, ub, title, resolution=20):
        x = np.linspace(lb[0], ub[0], resolution)
        y = np.linspace(lb[1], ub[1], resolution)
        z = []
        for i in x:
            for j in y:
                z.append(func(np.array([i, j])))
        z = np.array(z).reshape((resolution, resolution))

        plt.figure(figsize=(10, 10))

        # 绘制等高线
        plt.contour(x, y, z, levels=50, cmap="viridis")

        # 绘制所有点（在等高线之上）
        all_points = np.array(all_points)
        plt.scatter(
            all_points[:, 0],
            all_points[:, 1],
            color="black",
            label="All Points",
            zorder=5,
        )

        # 绘制轨迹（在等高线之上）
        track = np.array(track)
        plt.plot(
            track[:, 0], track[:, 1], color="red", linewidth=5, label="Track", zorder=10
        )

        # 添加标题和标签
        plt.title(title, fontsize=32)
        plt.legend(prop={"size": 20})
        plt.tick_params(axis="both", which="major", labelsize=20)

        save_path = "./figure/"
        os.makedirs(save_path, exist_ok=True)
        filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
        plt.savefig(filename, format="svg", dpi=150, bbox_inches="tight")
        plt.show()

    if F == None:
        for func_index in range(len(function_names)):
            algorithm = CQPSO(*get_parameter(function_names[func_index], CQPSO, dim=2))
            result = algorithm.optimize()[-1]
            plot_track_map(
                function_names[func_index],
                result[0],
                result[1],
                get_lb_ub_dim(function_names[func_index], dim=2)[0],
                get_lb_ub_dim(function_names[func_index], dim=2)[1],
                f"F{func_index+1} track",
            )
    else:
        func_index = F - 1
        algorithm = CQPSO(*get_parameter(function_names[func_index], CQPSO, dim=2))
        result = algorithm.optimize()[-1]
        plot_track_map(
            function_names[func_index],
            result[0],
            result[1],
            get_lb_ub_dim(function_names[func_index], dim=2)[0],
            get_lb_ub_dim(function_names[func_index], dim=2)[1],
            f"F{func_index+1} track",
        )


def base_box(base_func_test_data):
    for func_index in range(len(function_names)):
        func_data = []
        for algorithm_index in range(len(ablation_experiment_algorithms)):
            algorithm_data = []
            for proccessing in range(100):
                algorithm_data.append(
                    base_func_test_data[algorithm_index][proccessing][func_index]
                )
            func_data.append(algorithm_data)
        plot_boxplot(
            func_data,
            f"F{func_index+1} boxplot ablation",
            ablation_experiment_algorithms,
            "fitness",
            "./figure/",
        )


def project_box():
    for func_index in range(len(project_function_names)):
        if func_index == 8:
            continue
        func_data = []
        for algorithm_index in range(len(algorithm_names)):
            algorithm_data = []
            for proccessing in range(100):
                algorithm_data.append(
                    project_func_test_data[algorithm_index][proccessing][func_index]
                )
            func_data.append(algorithm_data)
        plot_boxplot(
            func_data,
            f"{project_function_names[func_index]} boxplot",
            algorithm_names,
            "value",
            "./figure/",
        )


def CQPSO_project_functions_value():
    def spring_design(x):
        def g_1(x_1, x_2, x_3):
            return 1 - x_2**3 * x_3 / (71785 * x_1**4)

        def g_2(x_1, x_2):
            return (
                (4 * x_2**2 - x_1 * x_2) / (12566 * (x_2 * x_1**3 - x_1**4))
                + 1 / (5108 * x_1**2)
                - 1
            )

        def g_3(x_1, x_2, x_3):
            return 1 - 140.45 * x_1 / (x_2**2 * x_3)

        def g_4(x_1, x_2):
            return (x_1 + x_2) / 1.5 - 1

        def f(x_1, x_2, x_3):
            return (x_3 + 2) * x_2 * x_1**2

        x = np.clip(x, np.array([0.05, 0.25, 2]), np.array([2, 1.3, 15]))
        x_1, x_2, x_3 = x[0], x[1], x[2]
        print("--------------spring design--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("g_1:", g_1(x_1, x_2, x_3))
        print("g_2:", g_2(x_1, x_2))
        print("g_3:", g_3(x_1, x_2, x_3))
        print("g_4:", g_4(x_1, x_2))
        print("f:", f(x_1, x_2, x_3))
        print("\n")

    def three_bar_truss(x):
        def g_1(x_1, x_2):
            return (
                2 * (2**0.5 * x_1 + x_2) * (2 * x_1 * x_2 + 2**0.5 * x_1**2) ** (-1) - 2
            )

        def g_2(x_1, x_2):
            return 2 * (2 * x_1 * x_2 + 2**0.5 * x_1**2) ** (-1) * x_2 - 2

        def g_3(x_1, x_2):
            return 2 * (x_1 + 2**0.5 * x_2) ** (-1) - 2

        def f(x_1, x_2):
            return (2 ** (3 / 2) * x_1 + x_2) * 100

        x = np.clip(x, np.array([1e-9, 1e-9]), np.array([1, 1]))
        x_1, x_2 = x[0], x[1]
        print("--------------three bar truss--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("g_1:", g_1(x_1, x_2))
        print("g_2:", g_2(x_1, x_2))
        print("g_3:", g_3(x_1, x_2))
        print("f:", f(x_1, x_2))
        print("\n")

    def cantilever_beam_design(x):
        def g_1(x_1, x_2, x_3, x_4, x_5):
            return 61 / x_1**3 + 37 / x_2**3 + 19 / x_3**3 + 7 / x_4**3 + 1 / x_5**3 - 1

        def f(x_1, x_2, x_3, x_4, x_5):
            return 0.0624 * (x_1 + x_2 + x_3 + x_4 + x_5)

        x = np.clip(
            x,
            np.array([0.01, 0.01, 0.01, 0.01, 0.01]),
            np.array([100, 100, 100, 100, 100]),
        )
        x_1, x_2, x_3, x_4, x_5 = x[0], x[1], x[2], x[3], x[4]
        print("--------------cantilever beam design--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("x_5:", x_5)
        print("g_1:", g_1(x_1, x_2, x_3, x_4, x_5))
        print("f:", f(x_1, x_2, x_3, x_4, x_5))
        print("\n")

    def welded_beam_design(x):
        sigma_max = 30000
        E = 30 * 1e6
        t_max = 13000
        L = 14
        P = 6000
        delta_max = 0.25
        G = 12 * 1e6

        def M(x_2):
            return (L + x_2 / 2) * P

        def R(x_1, x_2, x_3):
            return (x_2**2 / 4 + ((x_1 + x_3) / 2) ** 2) ** 0.5

        def delta(x_3, x_4):
            return 4 * P * L**3 / (E * x_3**3 * x_4)

        def J(x_1, x_2, x_3):
            return (x_2**2 / 12 + ((x_1 + x_3) / 2) ** 2) * x_1 * x_2 * 2 ** (3 / 2)

        def sigma(x_3, x_4):
            return 6 * P * L / (x_4 * x_3**2)

        def P_c(x_3, x_4):
            return (
                4.013
                * E
                * x_4**3
                * x_3
                / (6 * L**2)
                * (1 - x_3 / (2 * L) * (E / (4 * G)) ** 0.5)
            )

        def t_1(x_1, x_2):
            return P / (2**0.5 * x_1 * x_2)

        def t_2(x_1, x_2, x_3):
            return R(x_1, x_2, x_3) * M(x_2) / J(x_1, x_2, x_3)

        def t(x_1, x_2, x_3):
            return (
                t_1(x_1, x_2) ** 2
                + 2 * t_1(x_1, x_2) * t_2(x_1, x_2, x_3) * x_2 / (2 * R(x_1, x_2, x_3))
                + t_2(x_1, x_2, x_3) ** 2
            ) ** 0.5

        def g_1(x_1, x_2, x_3):
            return t(x_1, x_2, x_3) - t_max

        def g_2(x_3, x_4):
            return -sigma_max + sigma(x_3, x_4)

        def g_3(x_1, x_4):
            return x_1 - x_4

        def g_4(x_1, x_2, x_3, x_4):
            return 0.04811 * x_3 * x_4 * (14 + x_2) + 0.10471 * x_1**2 - 5

        def g_5(x_1):
            return -x_1 + 0.125

        def g_6(x_3, x_4):
            return delta(x_3, x_4) - delta_max

        def g_7(x_3, x_4):
            return P - P_c(x_3, x_4)

        def f(x_1, x_2, x_3, x_4):
            return 1.10471 * x_2 * x_1**2 + 0.04811 * x_3 * x_4 * (14 + x_2)

        x = np.clip(
            x,
            np.array([0.1, 0.1, 0.1, 0.1]),
            np.array([2, 10, 10, 2]),
        )
        x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]
        print("--------------welded beam design--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("g_1:", g_1(x_1, x_2, x_3))
        print("g_2:", g_2(x_3, x_4))
        print("g_3:", g_3(x_1, x_4))
        print("g_4:", g_4(x_1, x_2, x_3, x_4))
        print("g_5:", g_5(x_1))
        print("g_6:", g_6(x_3, x_4))
        print("g_7:", g_7(x_3, x_4))
        print("f:", f(x_1, x_2, x_3, x_4))
        print("\n")

    def gear_train_design(x):
        def f(x_1, x_2, x_3, x_4):
            return (1 / 6.931 - x_2 * x_3 / (x_1 * x_4)) ** 2

        x = np.round(np.clip(x, np.array([12, 12, 12, 12]), np.array([60, 60, 60, 60])))
        x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]
        print("--------------gear train design--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("f:", f(x_1, x_2, x_3, x_4))
        print("\n")

    def pressure_vessel_optimization(x):
        def g_1(x_1, x_3):
            return -x_1 + 0.0193 * x_3

        def g_2(x_2, x_3):
            return -x_2 + 0.00954 * x_3

        def g_3(x_3, x_4):
            return 1296000 - np.pi * x_3**2 * x_4 - 4 * np.pi / 3 * x_3**3

        def g_4(x_4):
            return x_4 - 240

        def f(x_1, x_2, x_3, x_4):
            return (
                19.84 * x_1**2 * x_3
                + 3.1661 * x_1**2 * x_4
                + 1.7781 * x_2 * x_3**2
                + 0.6224 * x_1 * x_3 * x_4
            )

        x = np.clip(x, np.array([1e-9, 1e-9, 10, 10]), np.array([100, 100, 200, 200]))
        x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]
        print("--------------pressure vessel optimization--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("g_1:", g_1(x_1, x_3))
        print("g_2:", g_2(x_2, x_3))
        print("g_3:", g_3(x_3, x_4))
        print("g_4:", g_4(x_4))
        print("f:", f(x_1, x_2, x_3, x_4))
        print("\n")

    def speed_reducer_optimization(x):
        def g_1(x_1, x_2, x_3):
            return -1 + 27 / (x_1 * x_2**2 * x_3)

        def g_2(x_1, x_2, x_3):
            return -1 + 397.5 / (x_1 * x_2**2 * x_3**2)

        def g_3(x_2, x_3, x_4, x_6):
            return -1 + 1.93 * x_4**3 / (x_2 * x_3 * x_6**4)

        def g_4(x_2, x_3, x_5, x_7):
            return -1 + 1.93 * x_5**3 / (x_2 * x_3 * x_7**4)

        def g_5(x_2, x_3, x_4, x_6):
            return ((745 * x_4 / (x_2 * x_3)) ** 2 + 16.9 * 1e6) ** 0.5 / (
                110 * x_6**3
            ) - 1

        def g_6(x_2, x_3, x_5, x_7):
            return ((745 * x_5 / (x_2 * x_3)) ** 2 + 157.5 * 1e6) ** 0.5 / (
                85 * x_7**3
            ) - 1

        def g_7(x_2, x_3):
            return -1 + x_2 * x_3 / 40

        def g_8(x_1, x_2):
            return -1 + 5 * x_2 / x_1

        def g_9(x_1, x_2):
            return -1 + x_1 / (12 * x_2)

        def g_10(x_4, x_6):
            return -1 + (1.5 * x_6 + 1.9) / x_4

        def g_11(x_5, x_7):
            return -1 + (1.1 * x_7 + 1.9) / x_5

        def f(x_1, x_2, x_3, x_4, x_5, x_6, x_7):
            return (
                0.7854 * x_1 * x_2**2 * (3.3333 * x_3**2 + 14.9334 * x_3 - 43.0934)
                - 1.5079 * x_1 * (x_6**2 + x_7**2)
                + 7.4777 * (x_6**3 + x_7**3)
                + 0.7854 * (x_4 * x_6**2 + x_5 * x_7**2)
            )

        x = np.clip(
            x,
            np.array([2.6, 0.7, 17, 7.3, 7.8, 2.9, 5]),
            np.array([3.6, 0.8, 28, 8.3, 8.3, 3.9, 5.5]),
        )
        x_1, x_2, x_3, x_4, x_5, x_6, x_7 = x[0], x[1], x[2], x[3], x[4], x[5], x[6]
        print("--------------speed reducer optimization--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("x_5:", x_5)
        print("x_6:", x_6)
        print("x_7:", x_7)
        print("g_1:", g_1(x_1, x_2, x_3))
        print("g_2:", g_2(x_1, x_2, x_3))
        print("g_3:", g_3(x_2, x_3, x_4, x_6))
        print("g_4:", g_4(x_2, x_3, x_5, x_7))
        print("g_5:", g_5(x_2, x_3, x_4, x_6))
        print("g_6:", g_6(x_2, x_3, x_5, x_7))
        print("g_7:", g_7(x_2, x_3))
        print("g_8:", g_8(x_1, x_2))
        print("g_9:", g_9(x_1, x_2))
        print("g_10:", g_10(x_4, x_6))
        print("g_11:", g_11(x_5, x_7))
        print("f:", f(x_1, x_2, x_3, x_4, x_5, x_6, x_7))
        print("\n")

    def I_beam_vertical_deflection_design(x):
        def g_1(h, b, t_w, t_f):
            return t_w * (h - 2 * t_f) + 2 * b * t_f - 300

        def g_2(h, b, t_w, t_f):
            x_1 = (
                2 * b * t_f * (4 * t_f**2 - 3 * h * (h - 2 * t_f))
                + t_w * (h - 2 * t_f) ** 3
            )
            x_2 = 2 * t_f * b**3 + (h - 2 * t_f) * t_w**3
            return 18 * h * 1e4 / x_1 + 15 * b * 1e3 / x_2

        def f(h, b, t_w, t_f):
            return 5000 / (
                t_w * (h - 2 * t_f) ** 3 / 12
                + b * t_f**3 / 6
                + 2 * b * t_f * (h - t_f) ** 2 / 4
            )

        x = np.clip(x, np.array([10, 10, 0.9, 0.9]), np.array([80, 50, 5, 5]))
        h, b, t_w, t_f = x[0], x[1], x[2], x[3]
        print("--------------I beam vertical deflection design--------------")
        print("h:", h)
        print("b:", b)
        print("t_w:", t_w)
        print("t_f:", t_f)
        print("g_1:", g_1(h, b, t_w, t_f))
        print("g_2:", g_2(h, b, t_w, t_f))
        print("f:", f(h, b, t_w, t_f))
        print("\n")

    def tubular_column_design(x):
        P, sigma_y, p, L, E = 2500, 500, 0.0025, 250, 8.5 * 1e5

        def g_1(d, t):
            return P / (np.pi * d * t * sigma_y) - 1

        def g_2(d, t):
            return 8 * P / (np.pi**3 * E * d * t * (d**2 + t**2)) - 1

        def g_3(d):
            return 2 / d - 1

        def g_4(d):
            return d / 14 - 1

        def g_5(t):
            return 1 / (5 * t) - 1

        def g_6(t):
            return 5 * t / 4 - 1

        def f(d, t):
            return 9.8 * d * t + 2 * d

        x = np.clip(x, np.array([2, 0.2]), np.array([14, 0.8]))
        d, t = x[0], x[1]
        print("--------------tubular column design--------------")
        print("d:", d)
        print("t:", t)
        print("g_1:", g_1(d, t))
        print("g_2:", g_2(d, t))
        print("g_3:", g_3(d))
        print("g_4:", g_4(d))
        print("g_5:", g_5(t))
        print("g_6:", g_6(t))
        print("f:", f(d, t))
        print("\n")

    spring_design(project_func_data_CQPSO_solution[0])
    three_bar_truss(project_func_data_CQPSO_solution[1])
    cantilever_beam_design(project_func_data_CQPSO_solution[2])
    welded_beam_design(project_func_data_CQPSO_solution[3])
    gear_train_design(project_func_data_CQPSO_solution[4])
    pressure_vessel_optimization(project_func_data_CQPSO_solution[5])
    speed_reducer_optimization(project_func_data_CQPSO_solution[6])
    I_beam_vertical_deflection_design(project_func_data_CQPSO_solution[7])
    tubular_column_design(project_func_data_CQPSO_solution[8])


def plot_all_optimization_curve(F=None):
    if F == None:
        for func_index in range(len(function_names)):
            algorithm = CQPSO(*get_parameter(function_names[func_index], CQPSO))
            algorithm.optimize()
            algorithm.plot_best(
                title=f"F{func_index+1} optimization curve", save_path="./figure/"
            )
    else:
        algorithm = CQPSO(*get_parameter(function_names[F - 1], CQPSO))
        algorithm.optimize()
        algorithm.plot_best(title=f"F{F} optimization curve", save_path="./figure/")


def plot_all_function_3D(F=None):
    def plot_function_3D(func, lb, ub, title, resolution=50):
        x = np.linspace(lb[0], ub[0], resolution)
        y = np.linspace(lb[1], ub[1], resolution)
        z = np.zeros((resolution, resolution))
        for i in range(resolution):
            for j in range(resolution):
                z[i, j] = func(np.array([x[i], y[j]]))

        fig = plt.figure(figsize=(10, 10))
        ax = fig.add_subplot(111, projection="3d")

        # 绘制3D曲面
        X, Y = np.meshgrid(x, y)
        ax.plot_surface(
            X, Y, z, cmap="viridis", alpha=0.8, rstride=1, cstride=1, edgecolor="none"
        )

        # 添加标题
        ax.set_title(title, fontsize=32)

        # 设置刻度线但不显示刻度值
        # ax.xaxis.set_major_formatter(plt.NullFormatter())
        # ax.yaxis.set_major_formatter(plt.NullFormatter())
        # ax.zaxis.set_major_formatter(plt.NullFormatter())

        save_path = "./figure/"
        os.makedirs(save_path, exist_ok=True)
        filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
        plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")
        plt.show()

    if F == None:
        for func_index in range(len(function_names)):
            plot_function_3D(
                function_names[func_index],
                get_lb_ub_dim(function_names[func_index], dim=2)[0],
                get_lb_ub_dim(function_names[func_index], dim=2)[1],
                f"F{func_index+1} 3D",
            )
    else:
        plot_function_3D(
            function_names[F - 1],
            get_lb_ub_dim(function_names[F - 1], dim=2)[0],
            get_lb_ub_dim(function_names[F - 1], dim=2)[1],
            f"F{F} 3D",
        )


def compress_directory(source_dir=None, output_path=None):
    """
    将指定目录压缩到ZIP文件中

    参数:
        source_dir (str): 要压缩的目录路径（默认当前目录）
        output_path (str): 输出ZIP文件完整路径（可选）
    """
    # 设置源目录
    if source_dir is None:
        source_dir = os.getcwd()

    # 规范化路径
    source_dir = os.path.abspath(source_dir)
    base_name = os.path.basename(source_dir)

    # 设置默认输出路径（上级目录）
    if output_path is None:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        parent_dir = os.path.dirname(source_dir)
        output_path = os.path.join(parent_dir, f"{base_name}_{timestamp}.zip")

    # 确保输出目录存在
    output_dir = os.path.dirname(output_path)
    os.makedirs(output_dir, exist_ok=True)

    print(f"正在压缩: {source_dir}")
    print(f"输出文件: {output_path}")

    # 创建ZIP文件
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            # 跳过输出文件所在目录
            if output_dir == root:
                continue

            for file in files:
                file_path = os.path.join(root, file)

                # 跳过ZIP文件自身（如果已存在）
                if file_path == output_path:
                    continue

                # 计算相对路径（保持目录结构）
                rel_path = os.path.relpath(file_path, source_dir)

                zipf.write(file_path, rel_path)
                print(f"添加: {rel_path}")

    # 检查文件大小
    file_size = os.path.getsize(output_path)
    size_str = (
        f"{file_size/1024/1024:.2f} MB"
        if file_size > 1024 * 1024
        else f"{file_size/1024:.2f} KB"
    )

    print(f"\n压缩完成! 文件大小: {size_str}")
    return output_path


def friedman_test(data):
    """Friedman检验（最小化问题）"""
    stat, p_value = friedmanchisquare(*[data[:, i] for i in range(data.shape[1])])
    return stat, p_value


def calculate_ranks(data):
    """计算排名（最小化问题）"""
    ranks = np.zeros_like(data)
    for i in range(data.shape[0]):
        ranks[i, :] = rankdata(data[i, :], method="average")
    avg_ranks = np.mean(ranks, axis=0)
    return ranks, avg_ranks


def nemenyi_test(avg_ranks, n_datasets, alpha=0.05):
    """Nemenyi检验"""
    k = len(avg_ranks)
    q_alpha = stats.distributions.studentized_range.ppf(1 - alpha, k, 1e6)
    CD = q_alpha * np.sqrt(k * (k + 1) / (6 * n_datasets))
    return CD


def bonferroni_dunn_test(avg_ranks, control_idx, n_datasets, alpha=0.05):
    """Bonferroni-Dunn检验"""
    k = len(avg_ranks)
    q_alpha = stats.distributions.norm.ppf(1 - alpha / (k - 1))
    CD = q_alpha * np.sqrt(k / (6 * n_datasets))
    return CD


def wilcoxon_holm_test(data, algorithm_names, alpha=0.05):
    """Wilcoxon符号秩检验+Holm校正"""
    n_algorithms = len(algorithm_names)
    n_pairs = n_algorithms * (n_algorithms - 1) // 2
    p_values = []
    adj_p_values = []  # 存储校正后的p值
    comparisons = []

    # 计算所有算法对的原始p值
    for i in range(n_algorithms):
        for j in range(i + 1, n_algorithms):
            _, p = wilcoxon(data[:, i], data[:, j])
            p_values.append(p)
            comparisons.append((i, j))

    # Holm校正
    reject, adj_p_values, _, _ = multipletests(p_values, alpha=alpha, method="holm")

    # 整理结果
    results = []
    for idx, (i, j) in enumerate(comparisons):
        results.append(
            {
                "algorithm1": algorithm_names[i],
                "algorithm2": algorithm_names[j],
                "p_value": p_values[idx],
                "adj_p_value": adj_p_values[idx],
                "significant": reject[idx],
            }
        )

    return results, adj_p_values, comparisons  # 返回校正后的p值


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.stats.multitest import multipletests


def plot_pvalue_heatmap(
    p_values,
    comparisons,
    algorithm_names,
    correction_method=None,
    title_suffix="",
    cbar_label="p-value",
    filename_suffix="",
):
    """
    绘制p值热力图（支持原始值或校正值）

    参数:
    p_values: 原始或校正后的p值列表
    comparisons: 算法对比较的索引列表
    algorithm_names: 算法名称列表
    correction_method: 使用的校正方法名称（用于标题）
    title_suffix: 标题后缀
    cbar_label: 颜色条标签
    filename_suffix: 文件名后缀
    """
    n_algorithms = len(algorithm_names)
    # 创建p值矩阵（初始化为NaN）
    p_matrix = np.full((n_algorithms, n_algorithms), np.nan)

    # 填充矩阵（包括对角线）
    for idx, (i, j) in enumerate(comparisons):
        p_matrix[i, j] = p_values[idx]
        p_matrix[j, i] = p_values[idx]

    # 创建DataFrame用于热力图
    df = pd.DataFrame(p_matrix, index=algorithm_names, columns=algorithm_names)

    # 创建热力图
    plt.figure(figsize=(12, 10))

    # 使用线性归一化
    norm = plt.Normalize(vmin=0, vmax=0.1)  # 设置线性尺度范围

    # 绘制热力图
    ax = sns.heatmap(
        df,
        annot=False,  # 不显示单元格中的数字
        cmap="coolwarm_r",  # 反转颜色映射，使低p值更醒目
        norm=norm,  # 使用线性归一化
        linewidths=0.5,
        # cbar_kws={"label": cbar_label},
        # annot_kws={"fontsize": 50},
    )
    cbar = ax.collections[0].colorbar
    cbar.ax.tick_params(labelsize=20)

    # 设置标题
    title = "Wilcoxon Signed-Rank Test"
    if correction_method:
        title += f" with {correction_method} Correction"
    if title_suffix:
        title += f" ({title_suffix})"
    plt.title(title, fontsize=24)

    # 调整布局
    plt.tight_layout()

    # 保存文件
    filename = "p_value_heatmap"
    if correction_method:
        filename += f"_{correction_method.lower()}"
    if filename_suffix:
        filename += f"_{filename_suffix}"
    plt.savefig(f"{filename}.png", dpi=300)
    plt.show()


def nonparametric_analysis(
    data, algorithm_names, correction_methods=["holm", "bonferroni", "fdr_bh"]
):
    """执行完整的非参数检验流程，支持多种校正方法"""
    # 1. Friedman检验
    friedman_stat, friedman_p = friedman_test(data)
    print(f"Friedman检验统计量: {friedman_stat:.4f}, p值: {friedman_p}")

    if friedman_p > 0.05:
        print("Friedman检验未发现显著差异 (p > 0.05)")
        return

    print("Friedman检验发现显著差异 (p < 0.05)，进行后续分析...")

    # 2. 计算排名并输出每个数据集上的排名
    ranks, avg_ranks = calculate_ranks(data)

    # 创建排名DataFrame
    rank_df = pd.DataFrame(ranks, columns=algorithm_names)
    rank_df.index.name = "Dataset"

    print("\n每个算法在每个数据集上的排名:")
    print(rank_df.to_string(float_format="%.2f"))

    print("\n算法平均排名（值越小越好）:")
    for name, rank in zip(algorithm_names, avg_ranks):
        print(f"{name}: {rank:.4f}")

    n_datasets = data.shape[0]

    # 3. Nemenyi检验（所有算法对比较）
    CD_nemenyi = nemenyi_test(avg_ranks, n_datasets)
    print(f"\nNemenyi检验临界差异值(CD): {CD_nemenyi:.4f}")

    # 4. Wilcoxon符号秩检验
    # 获取原始p值和比较对
    raw_p_values, comparisons = wilcoxon_test(data, algorithm_names)

    # 绘制原始p值热力图
    plot_pvalue_heatmap(
        raw_p_values,
        comparisons,
        algorithm_names,
        correction_method=None,
        title_suffix="Raw p-values",
        cbar_label="Raw p-value",
        filename_suffix="raw",
    )

    # 5. 多重比较校正
    print("\n多重比较校正结果:")

    # 存储所有校正结果
    all_results = {}

    # 对每种校正方法进行处理
    for method in correction_methods:
        # 应用多重比较校正
        rejected, adj_p_values, _, _ = multipletests(
            raw_p_values, alpha=0.05, method=method
        )

        # 存储结果
        method_results = []
        for idx, (i, j) in enumerate(comparisons):
            algo1 = algorithm_names[i]
            algo2 = algorithm_names[j]
            significant = rejected[idx]
            method_results.append(
                {
                    "algorithm1": algo1,
                    "algorithm2": algo2,
                    "raw_p_value": raw_p_values[idx],
                    "adj_p_value": adj_p_values[idx],
                    "significant": significant,
                }
            )

        all_results[method] = method_results

        # 输出结果
        print(f"\n{method.upper()}校正结果:")
        for res in method_results:
            sig = "显著" if res["significant"] else "不显著"
            print(
                f"{res['algorithm1']} vs {res['algorithm2']}: "
                f"原始p值={res['raw_p_value']:.4f}, 校正p值={res['adj_p_value']:.4f} - {sig}"
            )

        # 绘制校正p值热力图
        plot_pvalue_heatmap(
            adj_p_values,
            comparisons,
            algorithm_names,
            correction_method=method.upper(),
            cbar_label=f"{method.upper()} Adjusted p-value",
            filename_suffix=method.lower(),
        )

    return all_results


# 需要新增的函数：Wilcoxon符号秩检验（返回原始p值和比较对）
def wilcoxon_test(data, algorithm_names):
    """
    执行Wilcoxon符号秩检验，返回原始p值和比较对

    参数:
    data: 形状为(n_datasets, n_algorithms)的数组
    algorithm_names: 算法名称列表

    返回:
    raw_p_values: 原始p值列表
    comparisons: 算法对比较的索引列表
    """
    from scipy.stats import wilcoxon

    n_algorithms = len(algorithm_names)
    raw_p_values = []
    comparisons = []

    # 遍历所有算法对
    for i in range(n_algorithms):
        for j in range(i + 1, n_algorithms):
            # 执行Wilcoxon符号秩检验
            stat, p_value = wilcoxon(data[:, i], data[:, j])
            raw_p_values.append(p_value)
            comparisons.append((i, j))

    return raw_p_values, comparisons


def plot_H():
    # 假设您的数据数组名为 data
    fitness_list = np.array(
        [
            np.load(f"testData\\parameter_analyze\\CQPSO_base_{i}.npz")["fitness"]
            for i in range(5, 51)
        ]
    )

    fitness_max_median_min_list = []

    for i in range(46):
        a = []
        a.append(np.max(fitness_list[i, :, :], axis=0))
        a.append(np.median(fitness_list[i, :, :], axis=0))
        a.append(np.min(fitness_list[i, :, :], axis=0))
        fitness_max_median_min_list.append(a)

    fitness_max_median_min_numpy = np.transpose(
        np.array(fitness_max_median_min_list), (2, 1, 0)
    )

    for i in range(11):
        data = fitness_max_median_min_numpy[i]
        # 创建图形和坐标轴
        plt.figure(figsize=(12, 8))

        # 设置对数纵坐标
        plt.yscale("log")

        # 绘制三条折线
        plt.plot(np.arange(5, 51), data[0], "o-", label="Max", linewidth=2)  # 最大值
        plt.plot(np.arange(5, 51), data[1], "s-", label="Median", linewidth=2)  # 中位数
        plt.plot(np.arange(5, 51), data[2], "d-", label="Min", linewidth=2)  # 最小值

        # 添加标题和标签
        plt.title(
            f"Results for Different Values of Parameter H (F{i+1})",
            fontsize=28,
        )
        plt.xlabel("Value of H", fontsize=18)
        plt.ylabel("Fitness", fontsize=18)

        # 添加图例
        # plt.legend(fontsize=12)

        # 添加网格
        plt.grid(True, which="both", ls="--", alpha=0.5)

        # 调整x轴刻度
        plt.xticks(np.arange(5, 51, 5), fontsize=18)
        plt.yticks(fontsize=18)

        # 显示图形
        plt.tight_layout()
        plt.savefig(
            f"figure\\F{i+1}_Parameter_sensitivity_analysis.svg",
            format="svg",
            dpi=150,
            bbox_inches="tight",
        )
        plt.show()


if "__main__" == __name__:
    # 可调用的函数

    # 基准测试函数
    # base_median_best_worst_std()
    # base_box(base_func_test_data)
    # plot_all_track_map(F=6)
    # plot_all_optimization_curve()
    # plot_all_function_3D(F=11)

    # 工程问题
    # project_median_best_worst_std()
    # CQPSO_project_functions_value()
    # project_box()

    # 文件压缩（analyze需要单独复制）
    # zip_path = compress_directory(
    #     output_path=os.path.join(os.getcwd(), "my_archive.zip")
    # )

    # 消融实验
    # base_box(
    #     np.array(
    #         [
    #             np.load(f"testData\\{name}_base.npz")["fitness"]
    #             for name in ablation_experiment_algorithms
    #         ]
    #     )
    # )
    # base_median_best_worst_std(
    #     ablation_experiment_algorithms,
    #     np.array(
    #         [
    #             np.load(f"testData\\{name}_base.npz")["fitness"]
    #             for name in ablation_experiment_algorithms
    #         ]
    #     ),
    # )

    # 非参数检验

    # 准备数据 - 每个数据集一行，每个算法一列
    fitness_list = np.array(
        [
            np.load(f"testData\\parameter_analyze\\CQPSO_base_{i}.npz")["fitness"]
            for i in range(5, 51)
        ]
    )
    fitness_max_median_min_list = []
    for i in range(46):
        a = []
        a.append(np.max(fitness_list[i, :, :], axis=0))
        a.append(np.median(fitness_list[i, :, :], axis=0))
        a.append(np.min(fitness_list[i, :, :], axis=0))
        fitness_max_median_min_list.append(a)

    fitness_max_median_min_numpy = np.transpose(
        np.array(fitness_max_median_min_list), (2, 1, 0)
    )
    data = []
    for i in range(fitness_max_median_min_numpy.shape[0]):
        sum_rank = np.zeros(fitness_max_median_min_numpy.shape[-1])
        for j in range(fitness_max_median_min_numpy.shape[1]):
            sum_rank += rankdata(fitness_max_median_min_numpy[i, j])
        data.append(rankdata(sum_rank))
    name = [f"{i}" for i in range(5, 51)]

    all_methods = ["bonferroni", "holm", "simes-hochberg", "hommel", "fdr_bh", "fdr_by"]
    results = nonparametric_analysis(
        np.array(data), name, correction_methods=all_methods
    )
    # plot_H()
