import numpy as np


# 随机初始化
def random_init(lb, ub, dim, size):
    points = np.random.uniform(lb, ub, (size, dim))
    np.random.shuffle(points)
    return points


# 拉丁超立方抽样
def lhs_sample_init(lb, ub, dim, size):
    # 初始化样本矩阵
    samples = np.zeros((size, dim))

    # 对每个维度进行操作
    for dim in range(dim):
        # 生成一个随机排列
        perm = np.random.permutation(size)

        samples[:, dim] = (
            lb[dim] + (perm + np.random.rand()) * (ub[dim] - lb[dim]) / size
        )
    np.random.shuffle(samples)
    return samples


def lattice_points_init(lb, ub, dim, size):
    # 判断是否是质数
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(np.sqrt(n)) + 1):
            if n % i == 0:
                return False
        return True

    # 找到满足条件的最小素数
    prime_number_min = dim * 2 + 3
    while not is_prime(prime_number_min):
        prime_number_min += 1

    # 生成佳点集
    points = np.zeros((size, dim))
    for i in range(size):
        for j in range(dim):
            r = (2 * np.cos(2 * np.pi * (j + 1) / prime_number_min) * (i + 1)) % 1
            points[i, j] = lb[j] + r * (ub[j] - lb[j])

    np.random.shuffle(points)
    return points
