import numpy as np
from EA_toolbox import *


class GDQPSO:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_print,
        beta_1,
        beta_2,
        fai_2,
        beta,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.beta_1 = beta_1
        self.beta_2 = beta_2
        self.fai_2 = fai_2
        self.beta = beta

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        self.m = 0

    def optimize(self):
        for t in range(self.iter_num):
            # ������ʷ���ž�ֵ
            average_p = np.sum(self.P, axis=0) / self.size
            # ���ӽ����˶�
            for i in range(self.size):
                # ����ϵ��
                fai_1 = (self.beta_2 - self.beta_1) * (
                    self.iter_num - t
                ) / self.iter_num + self.beta_1
                # ��������������
                p_1 = self.P[i] * fai_1 + (1 - fai_1) * self.gbest
                p_2 = self.P[i] * self.fai_2 + (1 - fai_1) * self.gbest
                # ����������λ��
                random_factor_log = np.random.rand(self.dim)
                random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
                new_X_1 = p_1 + np.sign(random_factor_sign) * self.beta * np.abs(
                    average_p - self.X[i]
                ) * np.log(random_factor_log)
                new_X_2 = p_2 + np.sign(random_factor_sign) * self.beta * np.abs(
                    average_p - self.X[i]
                ) * np.log(random_factor_log)
                # ���������Χ�������ֵ
                out_range_index = np.where((new_X_1 < self.lb) | (new_X_1 > self.ub))[0]
                if len(out_range_index) > 0:
                    random_factor = np.random.rand(len(out_range_index))
                    new_X_1[out_range_index] = (
                        random_factor * self.lb[out_range_index]
                        + (1 - random_factor) * self.ub[out_range_index]
                    )
                out_range_index = np.where((new_X_2 < self.lb) | (new_X_2 > self.ub))[0]
                if len(out_range_index) > 0:
                    random_factor = np.random.rand(len(out_range_index))
                    new_X_2[out_range_index] = (
                        random_factor * self.lb[out_range_index]
                        + (1 - random_factor) * self.ub[out_range_index]
                    )
                # ̰��ѡ��
                new_X_score_1 = self.func(new_X_1)
                new_X_score_2 = self.func(new_X_2)
                if new_X_score_1 < new_X_score_2:
                    self.X[i] = new_X_1
                    self.X_score[i] = new_X_score_1
                else:
                    self.X[i] = new_X_2
                    self.X_score[i] = new_X_score_2
                # ���¸�������
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i].copy()
                    # ����ȫ�����ţ����δ���±�־λ��һ
                    if self.P_score[i] < self.gbest_score:
                        self.gbest = self.P[i].copy()
                        self.gbest_score = self.P_score[i].copy()
                        self.m = 0
                    else:
                        self.m += 1
                    # �����־λ�������ƣ�ʩ���Ŷ���̰��ѡ��
                    if self.m > 0.8 * self.iter_num:
                        random_factor = np.random.rand(self.dim)
                        gbest_r = random_factor * self.gbest + (1 - random_factor) * (
                            self.gbest - self.P[np.random.choice(self.size)]
                        )
                        out_range_index = np.where(
                            (gbest_r < self.lb) | (gbest_r > self.ub)
                        )[0]
                        if len(out_range_index) > 0:
                            random_factor = np.random.rand(len(out_range_index))
                            gbest_r[out_range_index] = (
                                random_factor * self.lb[out_range_index]
                                + (1 - random_factor) * self.ub[out_range_index]
                            )
                        gbest_r_score = self.func(gbest_r)
                        if gbest_r_score < self.gbest_score:
                            self.gbest = gbest_r
                            self.gbest_score = gbest_r_score

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
        )
