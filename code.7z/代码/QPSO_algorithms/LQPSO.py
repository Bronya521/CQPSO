import numpy as np
from EA_toolbox import *
import scipy


class LQPSO:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_print,
        beta_1,
        beta_2,
        lamda,
        ratio,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.beta_1 = beta_1
        self.beta_2 = beta_2
        self.lamda = lamda
        self.ratio = ratio

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        self.beta = 0

    def calculate_beta(self, t):
        self.beta = (self.beta_1 - self.beta_2) * (
            (self.iter_num - t) / self.iter_num
        ) ** 2 + self.beta_2

    def diversity(self):
        return np.sum(
            np.sqrt(np.sum((self.X - np.mean(self.P, axis=0)) ** 2, axis=1))
        ) / (self.size * np.sqrt(np.sum((self.ub - self.lb) ** 2)))

    def optimize(self):
        for t in range(self.iter_num):
            self.calculate_beta(t)
            # ������ʷ���ž�ֵ
            average_p = np.sum(self.P, axis=0) / self.size
            # ���ӽ����˶�
            for i in range(self.size):
                # ����������λ��
                random_factor = np.random.rand(self.dim)
                p = random_factor * self.P[i] + (1 - random_factor) * self.gbest
                if np.random.rand() < 0.5:
                    # ���������˶�
                    new_X = p + np.sign(
                        np.random.uniform(low=-1, high=1, size=self.dim)
                    ) * self.beta * np.abs(average_p - self.X[i]) * np.log(
                        np.random.rand(self.dim)
                    )
                else:
                    new_X = (
                        self.beta
                        * np.abs(average_p - self.X[i])
                        * np.log(np.random.rand(self.dim))
                    ) + np.abs(p - self.X[i]) * scipy.stats.levy.rvs(
                        loc=0, scale=1.5, size=self.dim
                    )
                # ���½������ڷ�Χ��
                new_X = np.clip(new_X, self.lb, self.ub)
                new_score = self.func(new_X)
                # ���µ�ǰ��Ⱥ
                self.X[i] = new_X.copy()
                self.X_score[i] = new_score.copy()
                # ���¸�������
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i].copy()
                    # ����ȫ������
                    if self.P_score[i] < self.gbest_score:
                        self.gbest = self.P[i].copy()
                        self.gbest_score = self.P_score[i].copy()
            if self.diversity() < self.lamda:
                worst_indexs = np.argmin(self.X_score)[-int(self.size * self.ratio) :]
                random_factor = np.random.rand(len(worst_indexs), self.dim)
                self.X[worst_indexs] = random_factor * self.lb + (1 - random_factor) * (
                    self.ub - self.lb
                )

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
        )
