import numpy as np
from EA_toolbox import *


class eQPSO:

    def __init__(
        self, func, init_function, dim, size, iter_num, lb, ub, is_print, w_1, w_2
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.w_1 = w_1
        self.w_2 = w_2

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        self.alpha = 0
        self.beta = 0
        self.not_updata_time = 0

    def calculate_alpha_beta(self, t):
        self.alpha = self.w_1 + (self.w_2 - self.w_1) * t / self.iter_num
        self.beta = 2 - 2 * t / self.iter_num

    def optimize(self):
        for t in range(self.iter_num):
            not_updata_flag = 1
            self.calculate_alpha_beta(t)
            # ���ӽ����˶�
            for i in range(self.size):
                gamma = -self.beta * np.log(np.random.rand())
                if gamma >= 2:
                    rand_X = self.X[np.random.choice(self.size)]
                else:
                    rand_X = (
                        self.alpha * np.random.rand() * self.P[i]
                        + (1 - self.alpha) * np.random.rand() * self.gbest
                    )
                random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
                new_X = rand_X + np.sign(random_factor_sign) * gamma * np.abs(
                    np.random.rand() * rand_X - self.X[i]
                )

                # ���½������ڷ�Χ��
                new_X = np.clip(new_X, self.lb, self.ub)
                new_score = self.func(new_X)
                # ���µ�ǰ��Ⱥ
                self.X[i] = new_X.copy()
                self.X_score[i] = new_score.copy()
                # ���¸�������
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i].copy()
                    # ����ȫ������
                    if self.P_score[i] < self.gbest_score:
                        self.gbest = self.P[i].copy()
                        self.gbest_score = self.P_score[i].copy()
                        not_updata_flag = 0

            if not not_updata_flag:
                self.not_updata_time = 0
            else:
                self.not_updata_time += 1
                if self.not_updata_time >= 50:
                    init_index = np.random.choice(
                        self.size, int(self.size * 0.2), replace=False
                    )
                    self.X[init_index] = (
                        np.random.rand(len(init_index), self.dim) * (self.ub - self.lb)
                        + self.lb
                    )
                    self.X_score[init_index] = np.array(
                        [self.func(self.X[index]) for index in init_index]
                    )
                    self.P[init_index] = self.X[init_index]
                    self.P_score[init_index] = self.X_score[init_index]

                    self.not_updata_time = 0

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
        )
